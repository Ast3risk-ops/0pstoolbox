Required while installing Windows 7,8 with in compact mode (v 10.0.14393.0 !)

wofadk.sys