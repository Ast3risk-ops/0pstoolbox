Place following files here:

Windows6.1-KB2864202-x??.msu

x??\XHCI\ucx01000.sys
x??\XHCI\usbd8.sys
x??\XHCI\usbhub3.sys
x??\XHCI\USBXHCI.cat
x??\XHCI\USBXHCI.inf
x??\XHCI\usbxhci.sys


Optional:

x??\UASPSTOR\uaspstor.cat
x??\UASPSTOR\uaspstor.inf
x??\UASPSTOR\uaspstor.sys


Links:

https://www.catalog.update.microsoft.com/Search.aspx?q=KB2864202%2BWindows%207
https://www.google.com/search?q=USB 3/XHCI+driver+stack+for+Windows+7/Vista